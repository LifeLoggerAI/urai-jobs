/**
 * Firestore Seeder
 * Usage:
 *   export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
 *   pnpm --filter urai-scripts install
 *   pnpm --filter urai-scripts run seed
 */
import admin from 'firebase-admin';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(__dirname, '..');

admin.initializeApp({ credential: admin.credential.applicationDefault() });
const db = admin.firestore();

const readJSON = (p)=> JSON.parse(fs.readFileSync(p, 'utf8'));

async function seedJobs() {
  const p = path.join(root, 'seed', 'ats.roles.json');
  if (!fs.existsSync(p)) return;
  const data = readJSON(p);
  for (const j of data.jobs || []) {
    const id = j.id || db.collection('jobs').doc().id;
    const doc = { ...j };
    delete doc.id;
    await db.collection('jobs').doc(id).set({ ...doc, createdAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    console.log('jobs:', id);
  }
}

async function seedMarketing() {
  const p = path.join(root, 'seed', 'marketing.sample.json');
  if (!fs.existsSync(p)) return;
  const data = readJSON(p);
  for (const c of data.marketing_campaigns || []) {
    const id = c.id || db.collection('marketing_campaigns').doc().id;
    const doc = { ...c };
    delete doc.id;
    await db.collection('marketing_campaigns').doc(id).set({ ...doc, createdAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    console.log('campaign:', id);
  }
  for (const r of data.marketing_recipients || []) {
    const id = r.id || (r.email || '').toLowerCase();
    if (!id) continue;
    const doc = { ...r };
    delete doc.id;
    await db.collection('marketing_recipients').doc(id).set({ ...doc, createdAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
    console.log('recipient:', id);
  }
}

async function main(){
  await seedJobs();
  await seedMarketing();
  console.log('done');
  process.exit(0);
}

main().catch(e=>{ console.error(e); process.exit(1); });
