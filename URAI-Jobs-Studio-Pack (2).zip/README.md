# URAI‑Jobs Firebase Studio Pack

This ZIP contains a ready‑to‑paste scaffold for the **URAI‑Jobs** project:
- Firestore/Storage **rules** and **indexes**
- Cloud Functions (Node 20, ESM, TypeScript)
- Admin HTTPS endpoints (secured via **Firebase Auth** custom claim `admin: true`)
- Email provider switch (**Resend** or **SendGrid**) + webhooks
- **Signed resume uploads** (V4), **reCAPTCHA** guarded
- **Campaigns**: send, open pixel, click tracking + UTM, webhooks, suppression
- **Analytics**: per‑campaign stats, daily rollups (cron), weekly summary email (cron), manual triggers
- Next.js App Router admin UI with client‑side **RBAC gate**

---

## 1) Prereqs
- Firebase project on **Blaze** plan (for scheduled functions)
- Enable: **Cloud Functions**, **Firestore**, **Cloud Scheduler**, **Storage**, **Auth (Email/Password)**
- Node 20 locally

## 2) Secrets (Functions)
Set what you need (provider, emails, captcha, etc.).

```bash
# email providers
firebase functions:secrets:set EMAIL_PROVIDER           # sendgrid | resend
firebase functions:secrets:set SENDGRID_API_KEY        # if using SendGrid
firebase functions:secrets:set RESEND_API_KEY          # if using Resend
firebase functions:secrets:set JOB_EMAIL_FROM

# recaptcha
firebase functions:secrets:set RECAPTCHA_SECRET

# analytics / tracking
firebase functions:secrets:set FUNCTIONS_REGION us-central1   # or your region
firebase functions:secrets:set TRACKING_BASE_URL https://<your-domain>   # optional

# notifications / auth
firebase functions:secrets:set ADMIN_EMAILS "you@domain.com,other@domain.com"
firebase functions:secrets:set SLACK_WEBHOOK_URL              # optional
```

Also set your web env (hosting/Vercel) using `apps/web/.env.example`:
```
NEXT_PUBLIC_FIREBASE_API_KEY=
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=
NEXT_PUBLIC_FIREBASE_PROJECT_ID=
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=
NEXT_PUBLIC_FIREBASE_APP_ID=
NEXT_PUBLIC_RECAPTCHA_SITE_KEY=
```

## 3) Install & Build Functions
```bash
cd functions
npm i
npm run build
```

## 4) Deploy (order)
```bash
# from project root
firebase deploy --only firestore:rules
firebase deploy --only firestore:indexes
firebase deploy --only storage
npm --prefix functions run build
firebase deploy --only functions
```

## 5) Admin Claim
Set `admin: true` on your user once:
```bash
node scripts/setAdminClaim.js   # edit UID inside first
```

## 6) Seeding (optional)
See `/seed/*.json` as reference content (jobs, schedules, campaigns). You can write a quick importer or add manually via the admin UI.

## 7) Web Admin
- Enable **Email/Password** in Firebase Auth.
- Deploy your Next.js app (or serve locally) and visit:
  - `/signin` → sign in as admin
  - `/admin` sections:
    - `/admin/campaigns` create + send
    - `/admin/email-events` live webhooks stream
    - `/admin/analytics` totals + **Send summary now**
    - `/admin/recipients` suppression list
    - `/admin/campaigns/[id]` campaign stats
    - `/admin/campaigns/[id]/charts` daily charts + **Re-run rollup**

## 8) Webhooks
Point providers to your Functions URLs:
- **Resend** → `https://<REGION>-<PROJECT>.cloudfunctions.net/webhook_resend`
- **SendGrid** → `https://<REGION>-<PROJECT>.cloudfunctions.net/webhook_sendgrid`

(Optional) add signature verification keys/secrets later.

## 9) Cron
- Daily rollup: 02:00 UTC → `campaign_stats/{id}/daily/{YYYY-MM-DD}`
- Weekly summary email: Mondays 09:00 UTC → `ADMIN_EMAILS`

## 10) Smoke Tests
- Create a campaign, send → check `/admin/email-events` for opens/clicks
- Apply flow: `/apply/[jobId]` → reCAPTCHA + signed upload → application created
- Suppression: trigger a bounce → recipient auto‑suppressed → send skips them

---

### Repo layout
```
firestore.rules
firestore.indexes.json
storage.rules
functions/...(TypeScript sources)
apps/web/... (Next.js app pages & Admin UI)
seed/...
scripts/setAdminClaim.js
```

If you want this split into a monorepo with workspaces (pnpm/yarn), or a ready‑to‑deploy Vercel config, say the word.


---

## Monorepo (pnpm) & CI

This pack is organized as a **pnpm** workspace:
- `functions` — Firebase Cloud Functions (TS/ESM)
- `apps/web` — Next.js web (Vercel-ready)
- `scripts` — Utilities (e.g., seeder)

Install once at repo root:
```bash
pnpm i
```

### Vercel (web)
- Set GitHub repo secrets:
  - `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
  - `NEXT_PUBLIC_*` envs for Firebase + `NEXT_PUBLIC_FUNCTIONS_BASE` (point this to your Cloud Functions base, e.g. `https://us-central1-<PROJECT>.cloudfunctions.net`)
- Push to `main` → `apps/web` builds & deploys via `.github/workflows/vercel-deploy.yml`.
- Local dev:
```bash
pnpm --filter urai-web dev
```

### Firebase Functions (CI)
- Set GitHub secret `FIREBASE_TOKEN` (from `firebase login:ci`).
- Push to `main` → Functions build & deploy via `.github/workflows/firebase-functions-deploy.yml`.

### Seeder
Use the Firestore **seeder** to import sample jobs/campaigns/recipients:
```bash
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
pnpm --filter urai-scripts i
pnpm --filter urai-scripts run seed
```

### Vercel rewrites for Functions
Set `NEXT_PUBLIC_FUNCTIONS_BASE` (e.g., `https://us-central1-<PROJECT>.cloudfunctions.net`) so Next.js rewrites map:
- `/resumes_createUploadUrl` → `${FUNCTIONS_BASE}/resumes_createUploadUrl`
- `/ats_secureApply` → `${FUNCTIONS_BASE}/ats_secureApply`
- `/admin_runWeeklySummary` → `${FUNCTIONS_BASE}/admin_runWeeklySummary`
- `/admin_runDailyRollup` → `${FUNCTIONS_BASE}/admin_runDailyRollup`
- `/admin_runCampaignRollup` → `${FUNCTIONS_BASE}/admin_runCampaignRollup`
- `/openPixel` → `${FUNCTIONS_BASE}/openPixel`
- `/trackRedirect` → `${FUNCTIONS_BASE}/trackRedirect`
