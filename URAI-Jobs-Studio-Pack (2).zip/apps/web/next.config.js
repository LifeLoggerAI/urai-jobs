/** @type {import('next').NextConfig} */
const FUNCTIONS_BASE = process.env.NEXT_PUBLIC_FUNCTIONS_BASE || '';
module.exports = {
  async rewrites() {
    if (!FUNCTIONS_BASE) return [];
    return [
      { source: '/resumes_createUploadUrl', destination: `${FUNCTIONS_BASE}/resumes_createUploadUrl` },
      { source: '/ats_secureApply', destination: `${FUNCTIONS_BASE}/ats_secureApply` },
      { source: '/admin_runWeeklySummary', destination: `${FUNCTIONS_BASE}/admin_runWeeklySummary` },
      { source: '/admin_runDailyRollup', destination: `${FUNCTIONS_BASE}/admin_runDailyRollup` },
      { source: '/admin_runCampaignRollup', destination: `${FUNCTIONS_BASE}/admin_runCampaignRollup` },
      { source: '/openPixel', destination: `${FUNCTIONS_BASE}/openPixel` },
      { source: '/trackRedirect', destination: `${FUNCTIONS_BASE}/trackRedirect` }
    ];
  }
};
