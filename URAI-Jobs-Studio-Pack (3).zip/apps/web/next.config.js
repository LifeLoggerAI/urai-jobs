/** @type {import('next').NextConfig} */
const FUNCTIONS_BASE = process.env.NEXT_PUBLIC_FUNCTIONS_BASE || '';
const config = {
  output: 'export', // static export for Firebase Hosting
  async rewrites() {
    // On Firebase Hosting we use hosting rewrites to functions, so no Next rewrites are required.
    // Keep this empty to avoid conflicts in export mode.
    return [];
  }
};
module.exports = config;
