'use client';
import React, { useEffect, useState } from 'react';
import { getFirestore, collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { app } from '../../lib/firebase';
export default function Logs(){
  const [rows,setRows]=useState<any[]>([]);
  useEffect(()=>{(async()=>{const db=getFirestore(app);const q=query(collection(db,'logs'), orderBy('createdAt','desc'), limit(200));const s=await getDocs(q);setRows(s.docs.map(d=>({id:d.id,...d.data()})));})()},[]);
  return (<main className="p-6 max-w-4xl mx-auto space-y-3">
    <h1 className="text-2xl font-semibold">Logs</h1>
    <ul className="grid gap-2">{rows.map(r=> <li key={r.id} className="border rounded-xl p-3">[{r.level}] {r.kind||''} {r.message||r.note||''}</li>)}</ul>
  </main>);
}
